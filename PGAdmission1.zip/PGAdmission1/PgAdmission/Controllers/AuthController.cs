﻿using PgAdmission.Core;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using PgAdmission.Core.Interface;
using PgAdmission.DBContext;
using PgAdmission.Models;
using System.Threading.Tasks;

namespace PgAdmission.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuth auth;

        private readonly ILogger<AuthController> logger;
        public AuthController(IAuth auth, ILogger<AuthController> logger)
        {
            this.auth = auth;
            this.logger = logger;
    
        }


        //[HttpPost]
        //[Route("UserLogin")]

        //public bool IsUserPresent(LoginModel data)
        //{
        //    var user = _context.UserT.FirstOrDefault(u => u.Email == data.Email && u.Password == data.Password);
        //    return user != null;
        //}


        //[HttpPost]
        //[Route("AdminLogin")]
        //public bool IsAdminPresent(LoginModel data)
        //{
        //    var admin = _context.AdminT.FirstOrDefault(a => a.Email == data.Email && a.Password == data.Password);
        //    return admin != null;
        //}


        //[HttpPost]
        //[Route("UserReg")]
        //public void SaveUser(UserModel user)
        //{
        //    _context.UserT.Add(user);
        //    _context.SaveChanges();
        //}


        //[HttpPost]
        //[Route("AdminReg")]
        //public void SaveAdmin(UserModel admin)
        //{

        //    if (admin.UserRole == "admin")
        //    {
        //        AdminModel a1 = new AdminModel();
        //        a1.Email = admin.Email;
        //        a1.Password = admin.Password;
        //        a1.MobileNumber = admin.MobileNumber;
        //        a1.UserRole = admin.UserRole;
        //        _context.AdminT.Add(a1);
        //        _context.SaveChanges();
        //    }
        //    else
        //    {
        //        _context.UserT.Add(admin);
        //        _context.SaveChanges();
        //    }
        //}
        [HttpPost]
        [Route("Register")]
        public async Task<ResponseModel> RegisterUser([FromBody] UserModel userModel)
        {
            try
            {
                if (userModel != null)
                {
                    var response = await auth.RegisterUser(userModel);
                    response.Message = "User Registered";
                    response.Status = true;
                    logger.LogInformation("USER CREATED");
                    return response;
                   
                }
                else
                {
                    ResponseModel response = new ResponseModel();
                    response.Message = "Send proper Request with proper input";
                    response.Status = true;
                    logger.LogInformation("unable to create user");
                    return response;
                }

            }
            catch (System.Exception ex)
            {

                ResponseModel response = new ResponseModel();
                response.ErrorMessage = "Send proper Request with proper input";
                response.Status = false;
                response.ErrorMessage = ex.Message;
                return response;
            }
        }


        [HttpPost]
        [Route("Token")]
        public ResponseModel GenerateToken([FromBody] LoginModel loginModel)
        {
            ResponseModel response = null;
            try
            {
                if (loginModel != null)
                {
                    if (!loginModel.Email.IsNullOrEmpty() && !loginModel.Password.IsNullOrEmpty())
                    {
                        logger.LogInformation("token created");
                        response = auth.GenerateToken(loginModel);

                        return response;

                    }
                    else
                    {
                        logger.LogInformation("token not created");
                        response = new ResponseModel();
                        response.Message = "UserName and Password";
                        response.Status = true;
                        return response;
                    }
                }
                else
                {
                    logger.LogInformation("token not created");
                    response = new ResponseModel();
                    response.Message = "Send proper data in request";
                    response.Status = true;
                    return response;
                }
            }
            catch (System.Exception ex)
            {

                response = new ResponseModel();
                response.Message = "Opps !";
                response.ErrorMessage = ex.Message;
                response.Status = false;
                logger.LogError($"{ex.Message} at TOKEN GENERATION");
                return response;
            }
        }


        [HttpGet]
        [Authorize]
        [Route("Welcome")]
        public string Welcome()
        {
            return "Wwelcome";
        }

    }
}
