import { Component } from '@angular/core';

@Component({
  selector: 'app-udashboard',
  templateUrl: './udashboard.component.html',
  styleUrls: ['./udashboard.component.css']
})
export class UDashboardComponent {

}
