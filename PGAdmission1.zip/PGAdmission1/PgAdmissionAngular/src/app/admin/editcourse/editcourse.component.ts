import { Component } from '@angular/core';
import { editcourseService } from 'src/app/services/editcourse.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router} from '@angular/router'
@Component({
  selector: 'app-update-institute',
  templateUrl: './editcourse.component.html',
  styleUrls: ['./editcourse.component.css'],
})
export class editcourseComponent {
  userform:FormGroup;
  constructor(private course: editcourseService, private router: Router) {
    const userDataState:any = this.router.getCurrentNavigation()?.extras?.state;
      this.userform = new FormGroup(
        {        
          courseId:new FormControl(userDataState.userData.courseId,[Validators.required]),
          courseName:new FormControl(userDataState.userData.courseName,[Validators.required]),
          courseDescription:new FormControl(userDataState.userData.courseDescription,[Validators.required]),
          courseDuration:new FormControl(userDataState.userData.courseDuration,[Validators.required]),
      });
  }
  getUserFormData(data: any) {
    this.course.updateCourse(data.courseId, data).subscribe((result: any) => {
      console.log(result);
      this.router.navigate(['']);
    });
  }
}